//WAP to delete an element at nth location of array..!!
import java.util.Scanner;
class Delete_Arr
{
	public static void main(String args[])
	{
		Scanner input= new Scanner(System.in);
		int[] a=new int[20];
		int n,i,j;		
		System.out.print("Enter the length of an array : ");
		n=input.nextInt();
		System.out.println("Enter the elements : ");
		for(i=0;i<n;i++)
		{
			a[i]=input.nextInt();
		}
		System.out.print("\nElements of Array are : ");
		for(i=0;i<n;i++)
		{
			System.out.print(a[i]+" ");
		}
		System.out.print("\nEnter the location from where you want to delete an element : ");
		int loc=input.nextInt();
		for(i=loc-1;i<=n-1;i++)
		{
			a[i]=a[i+1];
		}
		System.out.print("\nAfter insertion array is : ");
		for(i=0;i<n-1;i++)
		{
			System.out.print(a[i]+" ");
		}
	}
}