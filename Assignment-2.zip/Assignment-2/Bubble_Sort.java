//Bubble sort
import java.util.Scanner;
class Bubble_Sort
{
	public static void main(String args[])
	{
		Scanner input= new Scanner(System.in);
		int[] a=new int[20];
		int n,i,j;		
		System.out.print("Enter the length of an array : ");
		n=input.nextInt();
		System.out.println("Enter the elements : ");
		for(i=0;i<n;i++)
		{
			a[i]=input.nextInt();
		}
		System.out.print("Elements of Array are : ");
		for(i=0;i<n;i++)
		{
			System.out.print(a[i]+" ");
		}
		for(i=0;i<n;i++)
		{
			for(j=0;j<n-1;j++)
			{
				if(a[j]>a[j+1])
				{
					int temp=a[j];
					a[j]=a[j+1];
					a[j+1]=temp;
				}
			}
		}
		System.out.print("\n Sorted array is : ");
		for(i=0;i<n;i++)
		{
			System.out.print(a[i]+" ");
		}
	}
}