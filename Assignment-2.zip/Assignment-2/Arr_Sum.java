//WAP to take a sum of array elements
import java.util.Scanner;
class Arr_Sum
{
	public static void main(String args[])
	{
		Scanner input= new Scanner(System.in);
		int[] a=new int[20];
		int n,i,sum=0;		
		System.out.print("Enter the length of an array : ");
		n=input.nextInt();
		System.out.println("Enter the elements : ");
		for(i=0;i<n;i++)
		{
			a[i]=input.nextInt();
		}
		System.out.print("\nElements of Array are : ");
		for(i=0;i<n;i++)
		{
			System.out.print(a[i]+" ");
		}
		for(i=0;i<n;i++)
		{
			sum=sum+a[i];
		}
		System.out.print("\nSum of array's elements is : "+sum);
	}
}