//WAP to calculate the area of square
import java.util.Scanner;
class Square_Area
{
	public static void main(String args[])
	{
		Scanner input= new Scanner(System.in);
		int l,area=0;		
		System.out.print("Enter the side length of square: ");
		l=input.nextInt();
		area=l*l;
		System.out.println("Area of square is : "+area);		
	}
}