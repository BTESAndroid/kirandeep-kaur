//Selection sort
import java.util.Scanner;
class Selection_Sort
{
	public static void main(String args[])
	{
		Scanner input= new Scanner(System.in);
		int[] a=new int[20];
		int n,i,j,loc;		
		System.out.print("Enter the length of an array : ");
		n=input.nextInt();
		System.out.println("Enter the elements : ");
		for(i=0;i<n;i++)
		{
			a[i]=input.nextInt();
		}
		System.out.print("Elements of Array are : ");
		for(i=0;i<n;i++)
		{
			System.out.print(a[i]+" ");
		}
		
		for(i=0;i<n;i++)
		{
			int small=a[i];
			loc=i;
			for(j=i;j<n;j++)
			{
				if(a[j]<small)
				{
					small=a[j];
					loc=j;
				}
			}	
			int temp=a[i];
			a[i]=a[loc];
			a[loc]=temp;
		}
		System.out.print("\n Sorted array is : ");
		for(i=0;i<n;i++)
		{
			System.out.print(a[i]+" ");
		}
	}
}