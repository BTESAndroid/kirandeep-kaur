//Binary Search
import java.util.Scanner;
class Binary_search
{
	public static void main(String args[])
	{
		Scanner input= new Scanner(System.in);
		int[] a=new int[20];
		int n,i,j,beg,end,mid=0,loc;		
		System.out.print("Enter the length of an array : ");
		n=input.nextInt();
		System.out.println("Enter the elements : ");
		for(i=0;i<n;i++)
		{
			a[i]=input.nextInt();
		}
		for(i=0;i<n;i++)
		{
			for(j=0;j<n-1;j++)
			{
				if(a[j]>a[j+1])
				{
					int temp=a[j];
					a[j]=a[j+1];
					a[j+1]=temp;
				}
			}
		}
		System.out.print("\n Elements of array are : ");
		for(i=0;i<n;i++)
		{
			System.out.print(a[i]+" ");
		}
		System.out.print("\nEnter the element that you want to search : ");
		int item=input.nextInt();
		beg=0;end=n-1;
		mid=(int)(beg+end)/2;
		while(a[mid]!=item && beg<=end)
		{
			if(item<a[mid])
			{
				end=mid-1;
			}
			else
			{
				beg=mid+1;				
			}
			mid=(int)(beg+end)/2;
		}
		if(a[mid]==item)
		{
			loc=mid;
		}
		else
		{
			loc=0;
		}
		if(loc==0)
		{
			System.out.print("Item not found..!! ");
		}
		else
		{
			loc=loc+1;
			System.out.print("Item found at location : "+loc);
		}
	}
}