//Linear Search
import java.util.Scanner;
class Linear_Search
{
	public static void main(String args[])
	{
		Scanner input= new Scanner(System.in);
		int[] a=new int[20];
		int n,i,j,loc=0,count=0;		
		System.out.print("Enter the length of an array : ");
		n=input.nextInt();
		System.out.println("Enter the elements : ");
		for(i=0;i<n;i++)
		{
			a[i]=input.nextInt();
		}
		System.out.print("\nElements of Array are : ");
		for(i=0;i<n;i++)
		{
			System.out.print(a[i]+" ");
		}
		System.out.print("\nEnter the element that you want to search : ");
		int item=input.nextInt();
		for(i=0;i<n;i++)
		{
			if(item==a[i])
			{
				loc=i+1;
				System.out.println("Item found at location : "+loc);
				count++;
			}
		}
		if(count==0)
		{
			System.out.print("Item not found..!!");
		}
	}
}