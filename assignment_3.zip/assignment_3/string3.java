/* How to convert numeric String to int in Java? */
/*import java.util.Scanner;*/
public class string3 {
public static void main(String args[])
{
	String s="123";
	int a=Integer.parseInt(s);
	//Integer s2=Integer.toString(s);
	System.out.println(a);
}
}
