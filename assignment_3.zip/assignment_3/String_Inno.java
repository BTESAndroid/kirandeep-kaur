//WAP for Innovation of String..!!
class String_Inno
{
	public static void main(String arg[])
	{
		String s1="hello";
		String s2="world";
		boolean s3=s1.equals(s2);
		System.out.print(s3);
	}
}