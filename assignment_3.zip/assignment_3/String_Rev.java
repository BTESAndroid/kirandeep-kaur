import java.lang.*;
class String_Rev
{
	public static void main(String arg[])
	{
		String s="my name is kiran kaurr";
		String s2;
		System.out.println("String is : " + s);
		
		char[] array = s.toCharArray();
        
        array[0] = Character.toUpperCase(array[0]);
		array[3] = Character.toUpperCase(array[3]);
		array[8] = Character.toUpperCase(array[8]);
		array[11] = Character.toUpperCase(array[11]);
		array[17] = Character.toUpperCase(array[17]);
       for(int i=array.length-1;i>=0;i--)
	   {		   
	    System.out.print(array[i]);
	   }
	}
}