//capitalize first letter of string
import java.lang.*;
public class String1
{
public static void main(String args[])
{
	String s="i have no money";

	System.out.println(s);
	
     char[] arr=s.toCharArray();
     
      arr[0]=Character.toUpperCase(arr[0]);
      arr[2]=Character.toUpperCase(arr[2]);
      arr[7]=Character.toUpperCase(arr[7]);
     arr[10]=Character.toUpperCase(arr[10]);
     for(int i=0;i<arr.length;i++)
     {
    	 System.out.print(arr[i]);
     }
 	   
}}
