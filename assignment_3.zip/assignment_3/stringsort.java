import java.util.Arrays;

/*3. Sort the String using string API?*/


public class stringsort {

	public static void main(String args[])
	{
		String s="oocrl";
		char[] arr=s.toCharArray();		
		Arrays.sort(arr);
		String sorted = new String(arr);
	System.out.print("sorted string is  : "+sorted);
	
}
}