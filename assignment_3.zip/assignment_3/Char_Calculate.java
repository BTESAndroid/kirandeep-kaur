//WAP to calculate the occurance of character in string ..!!
import java.util.*;
class Char_Calculate
{
	public static void main(String arg[])
	{
		Scanner input=new Scanner(System.in);
		int count=0,i;
		System.out.print("Enter the string : ");
		String s1=input.next();
		s1=s1.toLowerCase();
		System.out.print("Enter the character that you want to find in string : ");
		char s2=input.next().charAt(0);
		char[] arr=s1.toCharArray();
		for(i=0;i<arr.length;i++)
		{
			if(arr[i]==s2)
			{
				count++;
			}
		}
		if(count==0)
		{
			System.out.print("No match found..!!!");
		}
		else
		{
			System.out.print("Character occured in the string "+count+" times..!!");
		}
	}
}
