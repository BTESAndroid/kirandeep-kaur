//WAP to calculate existance of vowels in string..!!
import java.util.*;
class String_Vowel
{
	public static void main(String arg[])
	{
		Scanner input=new Scanner(System.in);
		int vowel=0,space=0,consonent=0;
		System.out.print("Enter the string : ");
		String s1=input.nextLine();
		System.out.println("The String that you are entered : "+s1);
		s1=s1.toLowerCase();
		char[] a=s1.toCharArray();

		for(int i=0;i<a.length;i++)
		{
			if(a[i]=='a' || a[i]=='e' || a[i]=='i' || a[i]=='o' || a[i]=='v')
			{
				vowel++;
			}	
			else if(a[i]==' ')
			{
				space++;
			}
			else
			{
				consonent++;
			}
		}
		System.out.println("Number of Vowels in the String  are : "+vowel);
		System.out.println("Number of Consonents in the String  are : "+consonent);
		System.out.println("Number of Spaces in the String  are : "+space);
	}
}