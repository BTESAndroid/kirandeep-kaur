//Write a program search for a word in a String and replace all of its occurrences.
public class replace {
	public static void main(String args[])
	{
		String s="olivia is good girl";
		char s2='o';
		char s3='j';
		int loc;
		
		char[] arr=s.toCharArray();
		
		for(int i=0;i<arr.length;i++)		
			{
			
				if(s2==arr[i])
				{
					loc=i;
				System.out.println("location  : "+i);
				arr[i]=s3;
				}
		}
		String sorted = new String(arr);
		System.out.print("New string is  : "+sorted);
		
		
	}
}