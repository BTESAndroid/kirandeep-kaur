import java.util.Scanner;
class fibbo{  
public static void main(String args[])  
{    
 int n1=0,n2=1,fib,i;    

    System.out.println("Enter the number  till then you want fibbonaci series");

Scanner s=new Scanner(System.in);
int f=s.nextInt();
 System.out.print(n1+" "+n2);   
 for(i=2;i<f;++i)  
 {    
  fib=n1+n2;    
  System.out.print(" "+fib);    
  n1=n2;    
  n2=fib;    
 }    
  
}}  