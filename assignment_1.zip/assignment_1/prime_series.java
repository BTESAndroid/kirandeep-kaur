import java.util.Scanner;
class prime_series
{
   public static void main (String[] args)
   {		
      Scanner s = new Scanner(System.in);
      int i =0;
      int num =0;
    
      String  primeNumbers = "";
      System.out.println("Enter the value of n:");
      int n = s.nextInt();
      for (i = 1; i <= n; i++)  	   
      { 		 		  
         int c=0; 		  
         for(num =i; num>=1; num--)
         {
	    if(i%num==0)
	    {
		c = c + 1;
	    }
	 }
	 if (c ==2)
	 {
	    
	    primeNumbers = primeNumbers + i + " ";
	 }	
      }	
      System.out.println("Prime numbers from 1 to n are :");
      System.out.println(primeNumbers);
   }
}